﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.CRUDModel.FieldInfo
{
	public class FieldInfoEntityLISTModel
	{
		public List<FieldInfoEntityCRUDModel> Model { get; set; }
	}
}
