﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.CRUDModel.FieldInfo
{
	public class FieldInfoEntityCRUDModel
	{
		public int FieldInfoEntityID { get; set; }
		public string FieldName { get; set; }
	}
}
