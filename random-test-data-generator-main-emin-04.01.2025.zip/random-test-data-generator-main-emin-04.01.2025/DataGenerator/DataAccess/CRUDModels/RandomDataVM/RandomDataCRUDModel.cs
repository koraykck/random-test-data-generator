﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.CRUDModels.RandomDataVM
{
	internal class RandomDataCRUDModel
	{
	}
}
