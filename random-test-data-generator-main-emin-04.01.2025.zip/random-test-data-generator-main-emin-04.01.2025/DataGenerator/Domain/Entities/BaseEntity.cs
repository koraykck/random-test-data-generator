﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
	public abstract class BaseEntity
	{
		public int ID { get; set; }

		public DateTime CreatedDate { get; set; }
		public DateTime? DeletedDate { get; set; }

		public bool Status { get; set; }

		public int? FieldInfoID { get; set; }
		public virtual FieldInfoEntity? FieldInfo { get; set; }

		public BaseEntity()
		{
			CreatedDate = DateTime.Now;
			Status = true;
		}
	}

}
