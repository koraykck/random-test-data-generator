﻿using Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.RandomVariableEntities
{
	public class Email : BaseEntity
	{
		//public VariableType variableType { get; set; } = VariableType.String;
		public string EmailText { get; set; }


		//Relational Properties

	}
}
