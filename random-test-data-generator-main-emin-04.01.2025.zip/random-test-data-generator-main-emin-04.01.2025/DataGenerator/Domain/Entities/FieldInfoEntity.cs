﻿using Domain.Entities.RandomVariableEntities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities
{
	public class FieldInfoEntity
	{
		public int FieldInfoEntityID { get; set; }
		public string FieldName { get; set; }
		//public virtual ICollection<ClassEntity> ClassEntities { get; set; } = new List<ClassEntity>();
	}

}
