﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Enums
{
	public enum VariableType
	{
		Int = 1,
		String = 2,
		Bool = 3,
		Decimal = 4,
		Char = 5,
		Float = 6,
		Double = 7
	}
}
