﻿using Domain.Enums;
using Microsoft.AspNetCore.Mvc;
using Domain.Enums;
using DataAccess.CRUDModel.FieldInfo;
using DataAccess.Data;

namespace UI.Controllers
{
	public class RandomDataController : Controller
	{
		private readonly ApplicationDbContext _db;
		public RandomDataController(ApplicationDbContext db)
		{
			_db = db;
		}
		public IActionResult Index()
		{
			return View();
		}


		//bu kısım konusunu nasıl yapılabilcegini kafamda kuramadim, sadece bir fikir
		public IActionResult AddNewRandomDataVariableFieldInfo()
		{
			var model = Enum.GetValues(typeof(VariableType)).Cast<VariableType>();
			//yeni bir tablo oluşturulacak
			//int char vs değerleri kullanıcıdan istenecek
			return View(model);
		}


		//bu kısım konusunu nasıl yapılabilcegini kafamda kuramadim, sadece bir fikir
		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult AddNewRandomDataVariableFieldInfo(string tableName, int variableType)
		{
			//yeni bir tablo oluşturulacak
			//int char vs değerleri kullanıcıdan istenecek
			return View();
		}
		public IActionResult AddNewRandomData()
		{
			var CRUDModel = _db.FieldInfos.Select(c => new FieldInfoEntityCRUDModel
			{
				FieldInfoEntityID = c.FieldInfoEntityID,
				FieldName = c.FieldName
			}).ToList();
			var LISTModel = new FieldInfoEntityLISTModel
			{
				Model = CRUDModel
			};
			//var model = _db.
			//crud model işlemleri
			//hangi random verinin ekleneceğini seçme işlemi
			//ardından ileri diyerek veya ajax ile otomatik gerekli veriyi ekrana getirme
			return View(LISTModel);
		}
		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult AddNewRandomData(int? obj)
		{
			//crud model işlemleri
			//hangi random verinin ekleneceğini seçme işlemi
			//ardından ileri diyerek veya ajax ile otomatik gerekli veriyi ekrana getirme
			return View();
		}

		public IActionResult GetRandomData()
		{
			var FieldInfoEntityCRUDModel = _db.FieldInfos.Select(c => new FieldInfoEntityCRUDModel
			{
				FieldInfoEntityID = c.FieldInfoEntityID,
				FieldName = c.FieldName
			}).ToList();
			var FieldInfoEntityLISTModel = new FieldInfoEntityLISTModel
			{
				Model = FieldInfoEntityCRUDModel
			};
			return View(FieldInfoEntityLISTModel);
		}
	}



}